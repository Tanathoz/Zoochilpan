<?php

namespace Zoochilpan;

use Illuminate\Database\Eloquent\Model;

class Reporte extends Model
{
    //
}
