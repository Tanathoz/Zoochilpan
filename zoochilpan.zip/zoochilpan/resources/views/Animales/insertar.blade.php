@extends('Layouts.principal')


@section('content')
    <div class="container">
        <div class="row">



            {!! Form::open(['route'=>'animal.store','method'=>'POST']) !!}
            {!! Html::script('js/mostrarOpciones') !!}
            <div class="col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading">
                   <center> <h3 class="panel-title opcion_iluminada"> Registro de Animal </h3></center>
                </div>
                <div class="panel-body">
                    <a href="{{ url('/animal') }}" title="Volver"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> <span class="glyphicon glyphicon-arrow-left"></span></button></a>
                @include('Animales.form.registro')
                    <center>
                {!! Form::submit('Registrar',['class'=>'btn btn-primary']) !!}

                    </center>


            {!! Form::close() !!}
            </div>
            </div>
            </div>
        </div>
    </div>

@stop






