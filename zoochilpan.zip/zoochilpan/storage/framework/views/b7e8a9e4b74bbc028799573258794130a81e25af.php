<div class="form-group <?php echo e($errors->has('nombre') ? 'has-error' : ''); ?>">
    <?php echo Form::label('nombre', 'Nombre', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('nombre', null, ['class' => 'form-control','required' => 'required']); ?>

        <?php echo $errors->first('nombre', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('via') ? 'has-error' : ''); ?>">
    <?php echo Form::label('via', 'Via', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('via', null, ['class' => 'form-control','required' => 'required']); ?>

        <?php echo $errors->first('via', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Registrar', ['class' => 'btn btn-primary']); ?>

    </div>
</div>
