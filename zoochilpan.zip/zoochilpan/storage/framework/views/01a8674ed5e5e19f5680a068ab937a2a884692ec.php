<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">



            <?php echo Form::open(['route'=>'animal.store','method'=>'POST']); ?>

            <?php echo Html::script('js/mostrarOpciones'); ?>

            <div class="col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading">
                   <center> <h3 class="panel-title opcion_iluminada"> Registro de Animal </h3></center>
                </div>
                <div class="panel-body">
                    <a href="<?php echo e(url('/animal')); ?>" title="Volver"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> <span class="glyphicon glyphicon-arrow-left"></span></button></a>
                <?php echo $__env->make('Animales.form.registro', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <center>
                <?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>


                    </center>


            <?php echo Form::close(); ?>

            </div>
            </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>







<?php echo $__env->make('Layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>