<?php if(Session::has('message')): ?>
    <div class="alert alert-success alert-dismissible " role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <?php echo e(Session::get('message')); ?>

    </div>
<?php endif; ?>
<?php $__env->startSection('content'); ?>
    <table class="table ">
        <thead>
        <th>ID</th>
        <th>Nombre</th>
        <th>Apellido Paterno</th>
        <th>Apellido Materno</th>
        <th>Sexo</th>
        <th>Especialidad</th>
        <th>Area a cargo</th>
        <th>Acciones</th>
        </thead>

        <?php $__currentLoopData = $veterinarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $veterinario): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tbody>
            <td><?php echo e($veterinario->id); ?> </td>
            <td><?php echo e($veterinario->nombre); ?>  </td>
            <td> <?php echo e($veterinario->apellidoPaterno); ?> </td>
            <td> <?php echo e($veterinario->apellidoMaterno); ?> </td>
            <td> <?php echo e($veterinario->sexo); ?> </td>
            <td> <?php echo e($veterinario->especialidad); ?> </td>
            <td> <?php echo e($veterinario->areaEncargada); ?> </td>
            <td>   <?php echo link_to_route('veterinario.edit', $title = 'Editar', $parameters = $veterinario->id, $attributes = ['class'=>'btn btn-primary']); ?>

            </td>
            </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </table>
    <?php echo $veterinarios->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>