<?php $__env->startSection('content'); ?>

    <div class="col-md-8">
    <?php echo Form::open(['route'=>'familia.store','method'=>'POST']); ?>

    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><center><h3 class="opcion_iluminada">Registro De Familia</h3></center></h3>
        </div>
        <div class="panel-body">
            <a href="<?php echo e(url('/animal')); ?>" title="Volver"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> <span class="glyphicon glyphicon-arrow-left"></span></button></a>
            <?php echo $__env->make('Familias.forms.registro', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="form-group col-md-10  align-content-center">
            <?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>

            </div>
        </div>
    </div>

    <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>