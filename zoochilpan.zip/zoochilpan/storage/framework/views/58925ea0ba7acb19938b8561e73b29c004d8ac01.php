<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo Html::style('/css/bootstrap.css'); ?>

   <!--<?php echo Html::style('/css/estiloTablas.css'); ?>-->
    <title>Registro de ejemplar</title>
</head>
<body>
<section class="container">
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</section>
<?php echo Html::script('js/jquery-3.1.1.js'); ?>

<?php echo Html::script('js/bootstrap.min.js'); ?>


</body>

</html>