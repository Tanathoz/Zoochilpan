<?php $__env->startSection('content'); ?>

    <?php echo Form::model($veterinario,['route'=>['veterinario.update',$veterinario->id,'method'=>'PUT']]); ?>

    <input name="_method" type="hidden" value="PUT">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3>Editar el veterinario :<?php echo e($veterinario->nombre); ?></h3>
        </div>
        <div class="panel-body">
            <?php echo $__env->make('Veterinario.veterinario.forms.registro', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo Form::submit('Actualizar',['class'=>'btn btn-primary']); ?>



        </div>
    </div>

    <?php echo Form::close(); ?>



    <?php echo Form::open(['route'=>['veterinario.destroy',$veterinario->id,'method'=>'DELETE']]); ?>

    <input name="_method" type="hidden" value="DELETE">
    <br>
    <?php echo Form::submit('Eliminar',['class'=>'btn btn-danger']); ?>


    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>