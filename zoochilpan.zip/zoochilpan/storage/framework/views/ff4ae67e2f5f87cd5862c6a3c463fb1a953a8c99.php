<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
    <?php echo Form::open(['route'=>'veterinario.store','class' => 'form-horizontal','method'=>'POST']); ?>

            <div class="col-md-8">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"> Formularios de registro de Veterinario </h3>
        </div>
        <div class="panel-body">
            <?php echo $__env->make('Veterinario.veterinario.forms.registro', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="form-group  col-md-10 ">
            <?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>

            </div>
        </div>
    </div>

    <?php echo Form::close(); ?>

        </div>
    </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>