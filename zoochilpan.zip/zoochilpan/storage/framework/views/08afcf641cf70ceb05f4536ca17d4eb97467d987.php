<?php $__env->startSection('menu'); ?>
<?php if(Session::has('message')): ?>

    <div class="alert alert-success alert-dismissible " role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
       <?php echo e(Session::get('message')); ?>

    </div>

<?php elseif(Session::has('messageError')): ?>

    <div class="alert alert-danger alert-dismissible " role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <?php echo e(Session::get('messageError')); ?>

    </div>

<?php endif; ?>

<?php $__env->startSection('content'); ?>

    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading"><center><h3 class="opcion_iluminada">Gestion de Animales</h3></center></div>
            <div class="panel-body">
                <a href="<?php echo e(url('/animal/create')); ?>" class="btn btn-success btn-sm" title="Registrar animal">
                    <i class="fa fa-plus" aria-hidden="true"></i><span class="glyphicon glyphicon-plus">  </span>
                </a>

    <?php echo Form::open(['method' => 'GET', 'url' => '/animal', 'class' => 'navbar-form navbar-right', 'role' => 'search']); ?>

    <div class="input-group col-8">
        <input type="text" class="form-control" name="search" placeholder="Buscar...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <span class="glyphicon glyphicon-search">  </span>
                                    <i class="fa fa-search"> Buscar</i>
                                </button>
                            </span>
    </div>
    <?php echo Form::close(); ?>

    <br>
    <table class="table " >
        <thead>
            <th>Num</th>
            <th>Nombre Común</th>
            <th>Nombre Científico</th>
            <th>Clase</th>
            <th>Orden</th>
            <th>Familia</th>
            <th>Especie</th>
            <th>Habitat</th>
            <th>Acciones</th>
        </thead>

        <?php $__currentLoopData = $ejemplares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejemplare): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <tbody>
           <td><?php echo e($ejemplare->id); ?> </td>
           <td> <?php echo e($ejemplare->nombreComun); ?> </td>
           <td><?php echo e($ejemplare->nombreCientifico); ?>  </td>
           <td> <?php echo e($ejemplare->clase); ?> </td>
           <td> <?php echo e($ejemplare->orden); ?> </td>
           <td> <?php echo e($ejemplare->familia); ?> </td>
           <td> <?php echo e($ejemplare->especie); ?> </td>
           <td> <?php echo e($ejemplare->habitat); ?> </td>

           <td>
               <a href="<?php echo e(url('/animal/' . $ejemplare->id.'')); ?>" title="Ver Animal"><button class="btn btn-info btn-xs"><i class="fa fa-eye" aria-hidden="true"></i> <span class="glyphicon glyphicon-eye-open">  </span></button></a>
               <a href="<?php echo e(url('/animal/' . $ejemplare->id . '/edit')); ?>" title="Editar Animal"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> <span class="glyphicon glyphicon-pencil">  </span></button></a>

               <?php echo Form::open([
                                                 'method'=>'DELETE',
                                                 'url' => ['/animal', $ejemplare->id],
                                                 'style' => 'display:inline'
                                             ]); ?>

               <?php echo Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i><span class="glyphicon glyphicon-trash">  </span>', array(
                       'type' => 'submit',
                       'class' => 'btn btn-danger btn-xs',
                       'title' => 'Borrar animal',
                       'onclick'=>'return confirm("Confirmar borrado")'
               )); ?>

               <?php echo Form::close(); ?>

           </td>

        </tbody>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </table>
                <div class="pagination-wrapper"> <?php echo $ejemplares->appends(['search' => Request::get('search')])->render(); ?> </div>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('Layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>