<?php $__env->startSection('content'); ?>




            <?php echo Form::open(['route'=>'animal.store','method'=>'POST']); ?>

            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"> Formularios de registro de Ejemplar </h3>
                </div>
                <div class="panel-body">
                <?php echo $__env->make('Animales.form.registro', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>



                   </div>
                </div>

            <?php echo Form::close(); ?>



<?php $__env->stopSection(); ?>






<?php echo $__env->make('Layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>