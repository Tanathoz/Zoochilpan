<?php if(Session::has('message')): ?>
    <div class="alert alert-success alert-dismissible " role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
       <?php echo e(Session::get('message')); ?>

    </div>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <table class="table ">
        <thead>
            <th>Num</th>
            <th>Nombre Común</th>
            <th>Nombre Cientifico</th>
            <th>Familia</th>
            <th>Clase</th>
            <th>Orden</th>
            <th>Especie</th>
            <th>Origen</th>
            <th>Habitat</th>
            <th>Gestacion</th>
            <th>Camada</th>
            <th>Longevidad</th>
            <th>Sexo</th>
            <th>Peso</th>
            <th>Ubicación</th>
            <th>Alimentación</th>
            <th>¿Sabias qué?</th>
        </thead>

        <?php $__currentLoopData = $ejemplares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejemplare): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <tbody>
           <td><?php echo e($ejemplare->id); ?> </td>
           <td><?php echo e($ejemplare->nombreCientifico); ?>  </td>
           <td> <?php echo e($ejemplare->nombreComun); ?> </td>
           <td> <?php echo e($ejemplare->familia); ?> </td>
           <td> <?php echo e($ejemplare->clase); ?> </td>
           <td> <?php echo e($ejemplare->orden); ?> </td>
           <td> <?php echo e($ejemplare->especie); ?> </td>
           <td> <?php echo e($ejemplare->procedencia); ?> </td>
           <td> <?php echo e($ejemplare->habitat); ?> </td>
           <td> <?php echo e($ejemplare->gestacion); ?> </td>
           <td> <?php echo e($ejemplare->camada); ?> </td>
           <td> <?php echo e($ejemplare->longevidad); ?> </td>
           <td> <?php echo e($ejemplare->sexo); ?> </td>
           <td> <?php echo e($ejemplare->peso); ?> </td>
           <td> <?php echo e($ejemplare->ubicacionGeografica); ?> </td>
           <td> <?php echo e($ejemplare->Alimentacion); ?> </td>
           <td> <?php echo e($ejemplare->datoCurioso); ?> </td>
           <td>   <?php echo link_to_route('animal.edit', $title = 'Editar', $parameters = $ejemplare->id, $attributes = ['class'=>'btn btn-primary']); ?>

           </td>
        </tbody>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>