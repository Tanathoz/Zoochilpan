<?php if(Session::has('message')): ?>
    <div class="alert alert-success alert-dismissible " role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
       <?php echo e(Session::get('message')); ?>

    </div>

<?php elseif(Session::has('messageError')): ?>

    <div class="alert alert-danger alert-dismissible " role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <?php echo e(Session::get('messageError')); ?>

    </div>

<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <table class="table " >
        <thead>
            <th>Animal</th>
            <th>Marcaje</th>
            <th>Fecha Nacimiento</th>
            <th>Fecha Alta</th>
            <th>Sexo</th>
            <th>Nombre Propio</th>
            <th>Acciones</th>
        </thead>

        <?php $__currentLoopData = $ejemplares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejemplare): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <tbody>
           <td><?php echo e($ejemplare->idAnimal); ?> </td>
           <td><?php echo e($ejemplare->marcaje); ?>  </td>
           <td> <?php echo e($ejemplare->fechaNacimiento); ?> </td>
           <td> <?php echo e($ejemplare->fechaIngreso); ?> </td>
           <td> <?php echo e($ejemplare->sexo); ?> </td>
           <td> <?php echo e($ejemplare->alias); ?> </td>

           <td>   <?php echo link_to_route('animal.edit', $title = 'Editar', $parameters = $ejemplare->id, $attributes = ['class'=>'btn btn-primary']); ?>

               <?php echo link_to_route('animal.destroy', $title = 'Eliminar', $parameters = $ejemplare->id, $attributes = ['class'=>'btn btn-danger']); ?>

           </td>

        </tbody>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </table>

<?php echo $ejemplares->render(); ?>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('Layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>