<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">


            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading"><center><h3 class="opcion_iluminada">Gestión de Necropsias</h3></center></div>
                    <div class="panel-body">
                        <a href="<?php echo e(url('/necropsia/create')); ?>" class="btn btn-success btn-sm" title="agregar Necropsia">

                            <i class="fa fa-plus" aria-hidden="true"><span class="glyphicon glyphicon-plus"></span></i>

                        </a>

                        <?php echo Form::open(['method' => 'GET', 'url' => '/necropsia', 'class' => 'navbar-form navbar-right', 'role' => 'search']); ?>

                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Buscar...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <span class="glyphicon glyphicon-search">  </span>
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        <?php echo Form::close(); ?>


                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <table class="table table-borderless">
                                <thead>
                                    <tr>
                                        <th>ID</th><th>Lugar</th><th>Fecha</th><th>Hora</th><th>Causa Muerte</th><th>Marcaje</th><th>Ejemplar</th><th>sexo</th><th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $necropsia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->id); ?></td>
                                        <td><?php echo e($item->lugar); ?></td><td><?php echo e($item->fecha); ?></td><td><?php echo e($item->hora); ?></td> <td><?php echo e($item->diagnosticoMuerte); ?></td><td><?php echo e($item->marcajeEjemplar); ?></td><td><?php echo e($item->nombrePropio); ?></td><td><?php echo e($item->sexo); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('/necropsia/' . $item->id)); ?>" title="Ver Necropsia"><button class="btn btn-info btn-xs"><i class="fa fa-eye" aria-hidden="true"></i> <span class="glyphicon glyphicon-eye-open"></span></button></a>
                                            <a href="<?php echo e(url('/necropsia/' . $item->id . '/edit')); ?>" title="Editar Necropsia"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> <span class="glyphicon glyphicon-pencil"></span></button></a>
                                            <?php echo Form::open([
                                                'method'=>'DELETE',
                                                'url' => ['/necropsia', $item->id],
                                                'style' => 'display:inline'
                                            ]); ?>

                                                <?php echo Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i><span class="glyphicon glyphicon-trash"></span> ', array(
                                                        'type' => 'submit',
                                                        'class' => 'btn btn-danger btn-xs',
                                                        'title' => 'Borrar Necropsium',
                                                        'onclick'=>'return confirm("Confirmar borrado")'
                                                )); ?>

                                            <?php echo Form::close(); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </tbody>
                            </table>
                            <div class="pagination-wrapper"> <?php echo $necropsia->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>