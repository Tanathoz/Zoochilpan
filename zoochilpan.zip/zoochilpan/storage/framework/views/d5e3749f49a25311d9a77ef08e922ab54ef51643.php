

<div class="form-group col-md-10">
    <?php echo Form::label('Nombre '); ?>

    <?php echo Form::text('nombre',null,['class'=>'form-control','placeholder'=>'Arturo']); ?>


</div>


<div class="form-group col-md-10">
    <?php echo Form::label('Apellido Paterno '); ?>

    <?php echo Form::text('apellidoPaterno',null,['class'=>'form-control','placeholder'=>'Salazar']); ?>


</div>


<div class="form-group col-md-10">
    <?php echo Form::label('Apellido Materno '); ?>

    <?php echo Form::text('apellidoMaterno',null,['class'=>'form-control','placeholder'=>'Barrera']); ?>


</div>

<div class="form-group col-md-10">
    <?php echo Form::label('Sexo'); ?>

    <br>
    <?php echo Form::radio('sexo', 'M'); ?>

    <?php echo Form::label('M'); ?>

    <?php echo Form::radio('sexo', 'F'); ?>

    <?php echo Form::label('F'); ?>



</div>

<div class="form-group col-md-10">
    <?php echo Form::label('Especialidad '); ?>

    <?php echo Form::text('especialidad',null,['class'=>'form-control','placeholder'=>'pequeñas especies']); ?>


</div>



<div class="form-group col-md-10">
    <?php echo Form::label('Area a cargo '); ?>

    <?php echo Form::text('areaEncargada',null,['class'=>'form-control','placeholder'=>'primates ']); ?>


</div>

