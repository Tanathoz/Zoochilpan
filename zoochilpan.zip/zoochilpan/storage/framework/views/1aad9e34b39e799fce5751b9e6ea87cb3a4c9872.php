<div class="form-group col-md-4">
    <?php echo Form::label('Numero de registro'); ?>

    <?php echo Form::number('id',null,['class'=>'form-control','placeholder'=>'numero de identificacion']); ?>


</div>

<div class="form-group">
    <?php echo Form::label('Nombre cientifico'); ?>

    <?php echo Form::text('nombreCientifico',null,['class'=>'form-control','placeholder'=>'Pathera Leo']); ?>


</div>
<div class="form-group">
    <?php echo Form::label('Nombre Común'); ?>

    <?php echo Form::text('nombreComun',null,['class'=>'form-control','placeholder'=>'León']); ?>


</div>

<div class="form-group">

    <?php echo Form::label('Familia'); ?>

    <?php echo Form::text('familia',null,['class'=>'form-control','placeholder'=>'Felinos']); ?>


</div>


<div class="form-group">
    <?php echo Form::label('Clase'); ?>

    <?php echo Form::text('clase',null,['class'=>'form-control','placeholder'=>'Mamiferos']); ?>


</div>

<div class="form-group">
    <?php echo Form::label('Orden'); ?>

    <?php echo Form::text('orden',null,['class'=>'form-control','placeholder'=>'Carnivoros']); ?>


</div>
<div class="form-group">
    <?php echo Form::label('Especie'); ?>

    <?php echo Form::text('especie',null,['class'=>'form-control','placeholder'=>'Pathera ']); ?>


</div>
<div class="form-group">
    <?php echo Form::label('Procedencia'); ?>

    <?php echo Form::text('procedencia',null,['class'=>'form-control','placeholder'=>'Africa']); ?>


</div>

<div class="form-group">
    <?php echo Form::label('Habitat'); ?>

    <?php echo Form::text('habitat',null,['class'=>'form-control','placeholder'=>'selva']); ?>


</div>

<div class="form-group">
    <?php echo Form::label('Gestación'); ?>

    <?php echo Form::text('gestacion',null,['class'=>'form-control','placeholder'=>'110 dias']); ?>


</div>
<div class="form-group">
    <?php echo Form::label('Camada'); ?>

    <?php echo Form::text('camada',null,['class'=>'form-control','placeholder'=>'1-4 Crías']); ?>


</div>

<div class="form-group">
    <?php echo Form::label('Longevidad'); ?>

    <?php echo Form::text('longevidad',null,['class'=>'form-control','placeholder'=>'10-14 años']); ?>


</div>


<div class="form-group">
    <?php echo Form::label('Sexo'); ?>

    <br>
    <?php echo Form::radio('sexo', 'M'); ?>

    <?php echo Form::label('M'); ?>

    <?php echo Form::radio('sexo', 'F'); ?>

    <?php echo Form::label('F'); ?>



</div>


<div class="form-group">
    <?php echo Form::label('Peso'); ?>

    <?php echo Form::text('peso',null,['class'=>'form-control','placeholder'=>'130 kg']); ?>


</div>

<div class="form-group">
    <?php echo Form::label('Ubicación Geografíca'); ?>

    <?php echo Form::text('ubicacionGeografica',null,['class'=>'form-control','placeholder'=>'Noroeste de Africa']); ?>


</div>


<div class="form-group">
    <?php echo Form::label('Alimentacion'); ?>

    <?php echo Form::text('alimentacion',null,['class'=>'form-control','placeholder'=>'cebras,buffalos']); ?>


</div>

<div class="form-group">
    <?php echo Form::label('Dato Curioso'); ?>

    <?php echo Form::text('datoCurioso',null,['class'=>'form-control','placeholder'=>'Es el unico felino que forma manadas']); ?>


</div>