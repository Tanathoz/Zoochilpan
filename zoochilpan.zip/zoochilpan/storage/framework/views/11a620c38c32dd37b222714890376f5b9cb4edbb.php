<?php $__env->startSection('content'); ?>


    <?php echo Form::model($animal,['route'=>['animal.update',$animal->id,'method'=>'PUT']]); ?>

    <input name="_method" type="hidden" value="PUT">
    <div class="col-md-9">
        <div class="panel panel-default">
         <div class="panel-heading">
             <h3 class="opcion_iluminada">Datos Del Animal :<?php echo e($animal->nombreComun); ?></h3>
         </div>
             <div class="panel-body">


            <?php echo $__env->make('Animales.form.actualizar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                 <a href="<?php echo e(url('/animal')); ?>" class="btn btn-success btn-sm" title="cerrar">
                     <i class="fa fa-plus" aria-hidden="true"></i> Cerrar
                 </a>

         </div>
        </div>

    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>